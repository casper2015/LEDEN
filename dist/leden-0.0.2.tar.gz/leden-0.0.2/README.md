# LEDEN : Library for Evaluation of Decision Explanation Nuances

A library to evaluate the quality of explanations produced by explainers for the decisions of binary classifiers.

*(This library is under development. Please contact the author for any questions.)*

