# LEDEN : Library for Evaluation of Decision Explanation Nuances

A library to evaluate the quality of explanations produced by explainers for the decisions of binary classifiers.

